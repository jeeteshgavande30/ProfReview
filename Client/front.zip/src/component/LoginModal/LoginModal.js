import React from 'react';
import Backdrop from '../Backdrop/Backdrop';
import Modal1 from '../Modal/Modal1';
const LoginModal = ()=>{
    return (
     <React.Fragment>
         <Backdrop/>
        <Modal1 />
     </React.Fragment>
    );
}
export default LoginModal;